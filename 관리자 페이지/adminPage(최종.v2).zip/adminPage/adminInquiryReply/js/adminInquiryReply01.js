document.addEventListener("DOMContentLoaded", () => {
    const replyForm = document.getElementById("admin_inq_reply_form");
    const replyContent = document.getElementById("replyContent");
    const replyList = document.getElementById("admin_inq_reply_list");

    replyForm.addEventListener("submit", function (e) {
        e.preventDefault(); // 폼 기본 동작(새로고침) 막기

        const content = replyContent.value.trim();
        if (content === "") {
            alert("답변 내용을 입력하세요.");
            return;
        }

        // 현재 시간 생성
        const now = new Date();
        const dateStr = now.toLocaleString("ko-KR", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        });

        // 새 댓글(답변) 요소 생성
        const replyItem = document.createElement("div");
        replyItem.classList.add("admin_inq_reply_item");
        replyItem.innerHTML = `
            <div class="reply_header">
                <div class="reply_left">
                    <strong class="reply_author">관리자</strong>
                    <div class="reply_btns">
                        <button class="reply_edit_btn">수정</button>
                        <button class="reply_delete_btn">삭제</button>
                    </div>
                </div>
                <div class="reply_right">
                    <span class="reply_date">${dateStr}</span>
                </div>
            </div>
            <div class="reply_content">${content}</div>
        `;

        // 목록에 추가
        replyList.prepend(replyItem);

        // 입력칸 비우기
        replyContent.value = "";

        // 스크롤 이동 (최신 답변 보이게)
        replyList.scrollIntoView({ behavior: "smooth", block: "end" });
    });
});
