// 프로필, 사이드바 드롭다운은 모든 페이지에 적용
// 프로필 드롭다운
document.addEventListener("DOMContentLoaded", function() {
    const adminName = document.querySelector("#header_admin_name");
    const adminDropdown = document.querySelector("#aProfile_dropdown");

    // 이름 클릭 시 토글
    adminName.addEventListener("click", (e) => {
        e.stopPropagation(); // 클릭 이벤트 전파 방지
        adminDropdown.classList.toggle("active");
    });

    // 화면 클릭 시 드롭다운 닫기
    document.addEventListener("click", (e) => {
        if (!adminDropdown.contains(e.target) && e.target !== adminName) {
            adminDropdown.classList.remove("active");
        }
    });
})

// 사이드바 드롭다운
document.querySelectorAll('.sidebar_toggle').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.parentElement.classList.toggle('active');
    });
});

// 현재 페이지 URL 기준으로 열린 상태 유지
const sidebarCurrentPage = window.location.pathname.split("/").pop();
document.querySelectorAll('.aSidebar_sub_menu li a').forEach(link => {
    const linkHref = link.getAttribute('href');
    if (linkHref && sidebarCurrentPage === linkHref.split("/").pop()) {
        link.classList.add('active');
        link.closest('.aSidebar_sub').classList.add('active');
    }
});

// ===================================================================== //

// 회원 목록 더미 데이터
const users = [
    { userNo: 1, userName: "신짱구", userId: "shinchanggu", userEmail: "shinchanggu@email.com", userPhone: "010-1111-1111", userBirth: "1998-05-05", userAddr: "떡잎마을 1길 25" },
    { userNo: 2, userName: "봉미선", userId: "bongmison", userEmail: "bongmison@email.com", userPhone: "010-2222-2222", userBirth: "1973-06-25", userAddr: "떡잎마을 1길 25" },
    { userNo: 3, userName: "신형만", userId: "shinhyungman", userEmail: "shinhyungman@email.com", userPhone: "010-3333-3333", userBirth: "1971-03-11", userAddr: "떡잎마을 1길 25" },
    { userNo: 4, userName: "흰둥이", userId: "hindoongi", userEmail: "hindoongi@email.com", userPhone: "010-4444-4444", userBirth: "2018-01-01", userAddr: "떡잎마을 잔디밭" },
    { userNo: 5, userName: "철수", userId: "cheolsu", userEmail: "cheolsu@email.com", userPhone: "010-5555-5555", userBirth: "1998-07-08", userAddr: "떡잎마을 3길 12" },
    { userNo: 6, userName: "유리", userId: "yuri", userEmail: "yuri@email.com", userPhone: "010-6666-6666", userBirth: "1998-11-13", userAddr: "떡잎마을 3길 9" },
    { userNo: 7, userName: "훈이", userId: "hooni", userEmail: "hooni@email.com", userPhone: "010-7777-7777", userBirth: "1998-09-18", userAddr: "떡잎마을 4길 7" },
    { userNo: 8, userName: "맹구", userId: "maenggu", userEmail: "maenggu@email.com", userPhone: "010-8888-8888", userBirth: "1998-02-23", userAddr: "떡잎마을 2길 5" },
    { userNo: 9, userName: "신짱아", userId: "shinjjangah", userEmail: "shinjjangah@email.com", userPhone: "010-9999-9999", userBirth: "2021-09-01", userAddr: "떡잎마을 1길 25" },
    { userNo: 10, userName: "채성아", userId: "chaesunga", userEmail: "chaesunga@email.com", userPhone: "010-1010-1010", userBirth: "1985-10-01", userAddr: "떡잎유치원" },
    { userNo: 11, userName: "액션가면", userId: "actionmask", userEmail: "actionmask@email.com", userPhone: "010-1111-1212", userBirth: "1970-12-24", userAddr: "떡잎극장" },
    { userNo: 12, userName: "권지옹", userId: "kwonjeeong", userEmail: "kwonjeeong@email.com", userPhone: "010-1212-1313", userBirth: "1960-11-20", userAddr: "떡잎마을 사무소" },
    { userNo: 13, userName: "나미리", userId: "namiri", userEmail: "namiri@email.com", userPhone: "010-1313-1414", userBirth: "1989-04-15", userAddr: "떡잎백화점" },
    { userNo: 14, userName: "흑곰", userId: "heukgom", userEmail: "heukgom@email.com", userPhone: "010-1414-1515", userBirth: "1950-06-09", userAddr: "떡잎공원 근처" },
    { userNo: 15, userName: "수지", userId: "suji", userEmail: "suji@email.com", userPhone: "010-1515-1616", userBirth: "1998-04-05", userAddr: "떡잎마을 5길 8" }
];


// 페이지당 행 수
const rowsPerPage = 10;
let currentPage = 1;

// DOM 요소
const tableBody = document.querySelector("#admin_user_table tbody");
const pagingDiv = document.getElementById("pagination");


// 회원 목록 테이블 렌더링 함수
function renderTable(page) {
    tableBody.innerHTML = "";
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const pageData = users.slice(start, end);

    pageData.forEach((u, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${start + idx + 1}</td>
            <td><a href="userDetail.html?user=${u.userId}" class="admin_user_link">${u.userName} (${u.userId})</a></td>
            <td>${u.userEmail}</td>
            <td>${u.userPhone}</td>
            <td>${u.userBirth}</td>
            <td>${u.userAddr}</td>
        `;
        tableBody.appendChild(tr);
    });

}

// 페이지 버튼 동작
function renderPagination(totalItems) {
  pagingDiv.innerHTML = "";
  const pageCount = Math.ceil(totalItems / rowsPerPage);

  // 이전
  const prevBtn = document.createElement("button");
  prevBtn.textContent = "◀";
  prevBtn.disabled = currentPage === 1;
  prevBtn.addEventListener("click", () => changePage(currentPage - 1));
  pagingDiv.appendChild(prevBtn);

  // 번호 버튼
  for (let i = 1; i <= pageCount; i++) {
    const btn = document.createElement("button");
    btn.textContent = i;
    if (i === currentPage) btn.classList.add("active");
    btn.addEventListener("click", () => changePage(i));
    pagingDiv.appendChild(btn);
  }

  // 다음
  const nextBtn = document.createElement("button");
  nextBtn.textContent = "▶";
  nextBtn.disabled = currentPage === pageCount;
  nextBtn.addEventListener("click", () => changePage(currentPage + 1));
  pagingDiv.appendChild(nextBtn);
}

// 페이지 이동 통합 함수
function changePage(page) {
  currentPage = page;
  renderTable(currentPage);
  renderPagination(users.length);
}

// 초기 렌더링
renderTable(currentPage);
renderPagination(users.length);
