// 프로필, 사이드바 드롭다운은 모든 페이지에 적용
// 프로필 드롭다운
document.addEventListener("DOMContentLoaded", function() {
    const adminName = document.querySelector("#header_admin_name");
    const adminDropdown = document.querySelector("#aProfile_dropdown");

    // 이름 클릭 시 토글
    adminName.addEventListener("click", (e) => {
        e.stopPropagation(); // 클릭 이벤트 전파 방지
        adminDropdown.classList.toggle("active");
    });

    // 화면 클릭 시 드롭다운 닫기
    document.addEventListener("click", (e) => {
        if (!adminDropdown.contains(e.target) && e.target !== adminName) {
            adminDropdown.classList.remove("active");
        }
    });
})

// 사이드바 드롭다운
document.querySelectorAll('.sidebar_toggle').forEach(btn => {
    btn.addEventListener('click', () => {
        btn.parentElement.classList.toggle('active');
    });
});

// 현재 페이지 URL 기준으로 열린 상태 유지
const sidebarCurrentPage = window.location.pathname.split("/").pop();
document.querySelectorAll('.aSidebar_sub_menu li a').forEach(link => {
    const linkHref = link.getAttribute('href');
    if (linkHref && sidebarCurrentPage === linkHref.split("/").pop()) {
        link.classList.add('active');
        link.closest('.aSidebar_sub').classList.add('active');
    }
});

// ===================================================================== //

// 회원 목록 더미 데이터
const members = [
    { id: 1, name: "신짱구", userid: "shinchanggu", email: "shinchanggu@email.com", phone: "010-1111-1111", birth: "1998-05-05", address: "떡잎마을 1길 25" },
    { id: 2, name: "봉미선", userid: "bongmison", email: "bongmison@email.com", phone: "010-2222-2222", birth: "1973-06-25", address: "떡잎마을 1길 25" },
    { id: 3, name: "신형만", userid: "shinhyungman", email: "shinhyungman@email.com", phone: "010-3333-3333", birth: "1971-03-11", address: "떡잎마을 1길 25" },
    { id: 4, name: "흰둥이", userid: "hindoongi", email: "hindoongi@email.com", phone: "010-4444-4444", birth: "2018-01-01", address: "떡잎마을 잔디밭" },
    { id: 5, name: "철수", userid: "cheolsu", email: "cheolsu@email.com", phone: "010-5555-5555", birth: "1998-07-08", address: "떡잎마을 3길 12" },
    { id: 6, name: "유리", userid: "yuri", email: "yuri@email.com", phone: "010-6666-6666", birth: "1998-11-13", address: "떡잎마을 3길 9" },
    { id: 7, name: "훈이", userid: "hooni", email: "hooni@email.com", phone: "010-7777-7777", birth: "1998-09-18", address: "떡잎마을 4길 7" },
    { id: 8, name: "맹구", userid: "maenggu", email: "maenggu@email.com", phone: "010-8888-8888", birth: "1998-02-23", address: "떡잎마을 2길 5" },
    { id: 9, name: "신짱아", userid: "shinjjangah", email: "shinjjangah@email.com", phone: "010-9999-9999", birth: "2021-09-01", address: "떡잎마을 1길 25" },
    { id: 10, name: "채성아", userid: "chaesunga", email: "chaesunga@email.com", phone: "010-1010-1010", birth: "1985-10-01", address: "떡잎유치원" },
    { id: 11, name: "액션가면", userid: "actionmask", email: "actionmask@email.com", phone: "010-1111-1212", birth: "1970-12-24", address: "떡잎극장" },
    { id: 12, name: "권지옹", userid: "kwonjeeong", email: "kwonjeeong@email.com", phone: "010-1212-1313", birth: "1960-11-20", address: "떡잎마을 사무소" },
    { id: 13, name: "나미리", userid: "namiri", email: "namiri@email.com", phone: "010-1313-1414", birth: "1989-04-15", address: "떡잎백화점" },
    { id: 14, name: "흑곰", userid: "heukgom", email: "heukgom@email.com", phone: "010-1414-1515", birth: "1950-06-09", address: "떡잎공원 근처" },
    { id: 15, name: "수지", userid: "suji", email: "suji@email.com", phone: "010-1515-1616", birth: "1998-04-05", address: "떡잎마을 5길 8" }
];


// 페이지당 행 수
const rowsPerPage = 10;
let currentPage = 1;

// DOM 요소
const tableBody = document.querySelector("#admin_user_table tbody");
const totalPageEl = document.querySelector("#total_pages");
const currentPageEl = document.querySelector("#current_page");
const prevBtn = document.querySelector("#prev_page");
const nextBtn = document.querySelector("#next_page");


// 테이블 렌더링 함수
function renderTable(page) {
    tableBody.innerHTML = "";
    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const pageData = members.slice(start, end);

    pageData.forEach((m, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${start + idx + 1}</td>
            <td><a href="memberDetail.html?user=${m.userid}" class="member_link">${m.name} (${m.userid})</a></td>
            <td>${m.email}</td>
            <td>${m.phone}</td>
            <td>${m.birth}</td>
            <td>${m.address}</td>
        `;
        tableBody.appendChild(tr);
    });

    currentPageEl.textContent = currentPage;
    totalPageEl.textContent = Math.ceil(members.length / rowsPerPage);
}

// 페이지 버튼 동작
prevBtn.addEventListener("click", () => {
    if (currentPage > 1) {
        currentPage--;
        renderTable(currentPage);
    }
});

nextBtn.addEventListener("click", () => {
    if (currentPage < Math.ceil(members.length / rowsPerPage)) {
        currentPage++;
        renderTable(currentPage);
    }
});

// 초기 렌더링
renderTable(currentPage);
