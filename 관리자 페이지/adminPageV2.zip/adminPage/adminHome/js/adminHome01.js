// 프로필 드롭다운
document.addEventListener("DOMContentLoaded", function() {
    const adminName = document.querySelector("#header_admin_name");
    const dropdown = document.querySelector("#aProfile_dropdown");

    // 이름 클릭 시 토글
    adminName.addEventListener("click", (e) => {
        e.stopPropagation(); // 클릭 이벤트 전파 방지
        dropdown.classList.toggle("active");
    });

    // 화면 클릭 시 드롭다운 닫기
    document.addEventListener("click", (e) => {
        if (!dropdown.contains(e.target) && e.target !== adminName) {
            dropdown.classList.remove("active");
        }
    });
})