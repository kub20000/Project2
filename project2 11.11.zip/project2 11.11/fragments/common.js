document.addEventListener("DOMContentLoaded", async () => {
  const includes = document.querySelectorAll("[data-include]");

  // 모든 include 파일 로드
  await Promise.all([...includes].map(async (el) => {
    const url = el.getAttribute("data-include");
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`${url} 로드 실패`);
      el.innerHTML = await res.text();
    } catch (e) {
      el.innerHTML = `<div style="color:red;">${url} 불러오기 실패</div>`;
      console.error(e);
    }
  }));

  // ✅ include 완료 후 기능 실행
  initSidebar();
  initTabs();
  initPagination();
});

function initSidebar() {
  const sidebarItems = document.querySelectorAll(".sidebar-item");
  const submenuLinks = document.querySelectorAll(".submenu a");
  if (!sidebarItems.length) return;

  // === 1️⃣ 메인 메뉴 클릭 ===
  sidebarItems.forEach(item => {
    item.addEventListener("click", e => {
      const next = item.nextElementSibling;
      const hasSubmenu = next && next.classList.contains("submenu");

      // 서브메뉴가 있으면 기본 이동 막고 접기/펼치기
      if (hasSubmenu) {
        e.preventDefault();
        const isOpen = next.classList.contains("show");
        document.querySelectorAll(".submenu.show").forEach(s => s.classList.remove("show"));
        if (!isOpen) next.classList.add("show");
      }

      // active 표시
      sidebarItems.forEach(i => i.classList.remove("active"));
      item.classList.add("active");

      // 서브항목 current 초기화
      submenuLinks.forEach(a => a.classList.remove("current"));
    });
  });

  // === 2️⃣ 서브메뉴 클릭 ===
  submenuLinks.forEach(link => {
    link.addEventListener("click", e => {
      e.stopPropagation(); // 상위 클릭 방지
      submenuLinks.forEach(a => a.classList.remove("current"));
      link.classList.add("current");

      // 부모 메뉴 active 표시
      sidebarItems.forEach(i => i.classList.remove("active"));
      const parentItem = link.closest(".submenu").previousElementSibling;
      parentItem?.classList.add("active");
    });
  });

  // === 3️⃣ URL 기반 자동 활성화 (페이지 진입 시 표시용) ===
  const currentPath = location.pathname.split("/").pop();
  submenuLinks.forEach(link => {
    if (link.getAttribute("href") === currentPath) {
      link.classList.add("current");
      const parentItem = link.closest(".submenu")?.previousElementSibling;
      parentItem?.classList.add("active");
    }
  });
}



// === 탭 ===
function initTabs() {
  const tabs = document.querySelectorAll(".tab");
  const contents = document.querySelectorAll(".tab-content");
  if (!tabs.length) return;

  tabs.forEach((tab, idx) => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      contents.forEach(c => c.classList.remove("active"));
      tab.classList.add("active");
      contents[idx].classList.add("active");
    });
  });
}




  //약관동의
  document.addEventListener("DOMContentLoaded", function () {
    const allCheck = document.getElementById('allCheck');
    const checkboxes = document.querySelectorAll('.agree-check input[type="checkbox"]');
    const nextBtn = document.querySelector('.next');

    // 전체 동의 클릭 시 전체 체크박스 상태 변경
    allCheck.addEventListener('change', function() {
      checkboxes.forEach(chk => chk.checked = this.checked);
    });

    // 개별 체크 변경 시 전체동의 상태 갱신
    checkboxes.forEach(chk => {
      chk.addEventListener('change', () => {
        const allChecked = Array.from(checkboxes).every(c => c.checked);
        allCheck.checked = allChecked;
      });
    });

    // 다음 버튼 클릭 시 필수항목 확인
    nextBtn.addEventListener('click', function() {
      const requiredChecks = document.querySelectorAll('.agree-check input.required');
      const allRequiredChecked = Array.from(requiredChecks).every(chk => chk.checked);

      if (!allRequiredChecked) {
        alert('필수 약관에 모두 동의해야 합니다.');
        return;
      }

      alert('모든 필수 약관에 동의하셨습니다. 다음 단계로 이동합니다.');
      window.location.href = 'info.html';
    });
  });
  