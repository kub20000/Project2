package com.emergency.config;

import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAiConfig {

    @Bean
    public OpenAIClient openAIClient(@Value("${openai.api-key}") String apiKey) {
        // 환경변수나 properties에서 읽은 키로 클라이언트 생성
        return OpenAIOkHttpClient.builder()
                .apiKey(apiKey)
                .build();
    }
}
