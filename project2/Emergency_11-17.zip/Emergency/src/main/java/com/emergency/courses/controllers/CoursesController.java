package com.emergency.courses.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CoursesController {

    private void setupCoursePage(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "COURSE"); // 헤더 메뉴 활성화
        model.addAttribute("showSidebar", true);    // 교육과정 사이드바 사용
        model.addAttribute("contentTemplate", contentTemplate);

        model.addAttribute("pageCss", List.of(
                "/css/fragments_css/common.css",
                "/css/fragments_css/components.css",
                "/css/courses_css/courses.css",
                "/css/courses_css/about.css"
        ));
        model.addAttribute("pageJs", List.of("/fragments_js/pageNationC.JS"));
    }

    // 강의 목록(전체)
    @GetMapping({"/courses", "/courses/courses", "/courses/courses.html"})
    public String courseList(Model model) {
        // templates/pages/courses.html
        setupCoursePage(model, "강의목록", "courses/courses");
        return "layout";
    }

    // 출혈
    @GetMapping({"/courses/course1", "/courses/course1.html"})
    public String courseBleeding(Model model) {
        // templates/pages/course1.html
        setupCoursePage(model, "강의목록 - 출혈", "courses/course1");
        return "layout";
    }

    // 기도막힘
    @GetMapping({"/courses/course2", "/courses/course2.html"})
    public String courseAirway(Model model) {
        // templates/pages/course2.html
        setupCoursePage(model, "강의목록 - 기도막힘", "courses/course2");
        return "layout";
    }

    // 골절
    @GetMapping({"/courses/course3", "/courses/course3.html"})
    public String courseFracture(Model model) {
        // templates/pages/course3.html
        setupCoursePage(model, "강의목록 - 골절", "courses/course3");
        return "layout";
    }

    // 화상
    @GetMapping({"/courses/course4", "/courses/course4.html"})
    public String courseBurn(Model model) {
        // templates/pages/course4.html
        setupCoursePage(model, "강의목록 - 화상", "courses/course4");
        return "layout";
    }

    // 소개글
    @GetMapping({"/courses/about", "/courses/about.html"})
    public String about(Model model) {
        // templates/pages/about.html
        setupCoursePage(model, "응급처치 소개", "courses/about");
        return "layout";
    }

    // 교육자료 - 전체
    @GetMapping({"/courses/data", "/courses/data.html"})
    public String dataAll(Model model) {
        // templates/pages/data.html
        setupCoursePage(model, "교육 자료", "courses/data");
        return "layout";
    }

    // 교육자료 - 출혈
    @GetMapping({"/courses/data1", "/courses/data1.html"})
    public String dataBleeding(Model model) {
        // templates/pages/data1.html
        setupCoursePage(model, "교육 자료 - 출혈", "courses/data1");
        return "layout";
    }

    // 교육자료 - 기도막힘
    @GetMapping({"/courses/data2", "/courses/data2.html"})
    public String dataAirway(Model model) {
        // templates/pages/data2.html
        setupCoursePage(model, "교육 자료 - 기도막힘", "courses/data2");
        return "layout";
    }

    // 교육자료 - 심정지
    @GetMapping({"/courses/data3", "/courses/data3.html"})
    public String dataCardiac(Model model) {
        // templates/pages/data3.html
        setupCoursePage(model, "교육 자료 - 심정지", "courses/data3");
        return "layout";
    }

    // 교육자료 - 화상
    @GetMapping({"/courses/data4", "/courses/data4.html"})
    public String dataBurn(Model model) {
        // templates/pages/data4.html
        setupCoursePage(model, "교육 자료 - 화상", "courses/data4");
        return "layout";
    }
}
