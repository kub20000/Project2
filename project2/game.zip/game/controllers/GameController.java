package com.emergency.game.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class GameController {

    // 게임 페이지 공통 세팅 (NewsController의 setupNews 와 같은 역할)
    private void setupGame(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "GAME");   // 헤더에서 GAME 메뉴 활성화
        model.addAttribute("showSidebar", true);    // 게임 사이드바 사용 (sidebarG)

        // layout.html에서 th:replace="~{${contentTemplate} :: content}" 로 사용
        model.addAttribute("contentTemplate", contentTemplate);

        // 페이지 전용 CSS (필요하면 여러 개 넣어서 사용 가능)
        model.addAttribute("pageCss", List.of(
                "/css/game/game.css"
        ));
    }

    /**
     * /game 또는 /game/ 로 들어오면
     * 게임 소개 페이지로 리다이렉트
     */
    @GetMapping({"/game", "/game/"})
    public String redirectToAboutGame() {
        return "redirect:/game/aboutGame.html";
    }

    /**
     * 게임 소개 페이지
     * URL: /game/aboutGame, /game/aboutGame.html
     * template: templates/game/aboutGame.html
     */
    @GetMapping({"/game/aboutGame", "/game/aboutGame.html"})
    public String aboutGame(Model model) {
        // templates/game/aboutGame.html :: content
        setupGame(model, "응급 처치 시뮬레이션 게임", "game/aboutGame");
        return "layout";
    }

    /**
     * 배지 보관함 페이지
     * URL: /game/myGame, /game/myGame.html
     * template: templates/game/myGame.html
     */
    @GetMapping({"/game/myGame", "/game/myGame.html"})
    public String myGame(Model model) {

        // 기본 레이아웃/사이드바 세팅
        setupGame(model, "배지 보관함", "game/myGame");

        // (임시) 사용자 이름 – 나중에 세션 연동해서 교체 가능
        String userName = "회원";
        model.addAttribute("userName", userName);

        // 배지 획득 여부 (나중에 DB 값으로 교체)
        Map<String, Boolean> badgeData = new HashMap<>();
        badgeData.put("bleeding", true);   // 출혈 배지 보유
        badgeData.put("airway", false);    // 기도 막힘 미보유
        badgeData.put("cpr", true);        // 심정지 배지 보유
        badgeData.put("burn", false);      // 화상 배지 미보유
        model.addAttribute("badgeData", badgeData);

        // 클리어 날짜 (없으면 템플릿에서 '미획득' 표시)
        Map<String, String> badgeDates = new HashMap<>();
        badgeDates.put("bleeding", "2025-11-19");
        badgeDates.put("cpr", "2025-11-19");
        model.addAttribute("badgeDates", badgeDates);

        return "layout";
    }

    /**
     * 게임 실행 페이지
     * URL: /game/list, /game/list.html
     * template: templates/game/gameList.html (나중에 생성)
     */
    @GetMapping({"/game/list", "/game/list.html"})
    public String gameList(Model model) {

        // templates/game/gameList.html :: content  (나중에 만들면 됨)
        setupGame(model, "게임 실행", "game/gameList");
        return "layout";
    }
}
