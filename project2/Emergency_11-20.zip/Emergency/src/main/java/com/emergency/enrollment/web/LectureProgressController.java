package com.emergency.enrollment.web;

import com.emergency.enrollment.service.EnrollmentService;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 강의 시청 구간(이어보기) 저장/조회용 REST 컨트롤러
 *
 *  - POST /api/lecture-progress
 *      시청 구간 저장 (진도율 갱신까지 포함)
 *
 *      요청 JSON 예)
 *      {
 *          "enrollmentId": 1,
 *          "lectureId": 10,
 *          "watchSec": 123,
 *          "completed": false
 *      }
 *
 *  - GET /api/lecture-progress/{enrollmentId}/{lectureId}
 *      마지막 시청 위치(초)를 조회해서 이어보기 시작 위치로 사용
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/lecture-progress")
public class LectureProgressController {

    private final EnrollmentService enrollmentService;

    /** 시청 구간 + 완료 여부 저장 */
    @PostMapping
    public void saveProgress(@RequestBody SaveRequest request) {
        enrollmentService.updateLectureProgress(
                request.getEnrollmentId(),
                request.getLectureId(),
                request.getWatchSec(),
                request.isCompleted()
        );
    }

    /** 이어보기용 마지막 시청 구간 조회 */
    @GetMapping("/{enrollmentId}/{lectureId}")
    public ProgressResponse getProgress(@PathVariable Long enrollmentId,
                                        @PathVariable Long lectureId) {

        Integer watchSec = enrollmentService.getLastWatchSec(enrollmentId, lectureId);
        if (watchSec == null) {
            watchSec = 0;
        }
        return new ProgressResponse(watchSec);
    }

    /** 저장용 요청 바디 DTO */
    @Data
    public static class SaveRequest {
        private Long enrollmentId;
        private Long lectureId;
        private int watchSec;
        private boolean completed;
    }

    /** 조회 응답 DTO */
    @Data
    public static class ProgressResponse {
        private final int watchSec;
    }
}
