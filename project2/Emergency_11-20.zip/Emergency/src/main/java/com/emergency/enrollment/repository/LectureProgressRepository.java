package com.emergency.enrollment.repository;

/**
 * lecture_progress 테이블 접근용 Repository
 *
 * 사용 목적
 *  - 새로 수강신청(enrollment)할 때,
 *    그 강의의 모든 차시에 대해 초기 진도 데이터(watch_sec=0, completed=0)를 생성
 *  - 강의 시청 중/종료 시 구간/완료 여부를 저장하고,
 *    이어보기용 마지막 시청 위치를 조회
 */
public interface LectureProgressRepository {

    /** 단일 차시에 대한 초기 진도 row INSERT */
    void insertInitial(Long enrollmentId, Long courseLectureId);

    /** 시청 구간 및 완료 여부 UPDATE (이어보기/진도 저장용) */  // [추가]
    void updateProgress(Long enrollmentId,
                        Long courseLectureId,
                        int watchSec,
                        boolean completed);

    /** 이어보기용 마지막 시청 구간(초) 조회. 없으면 null 반환 */   // [추가]
    Integer findWatchSec(Long enrollmentId,
                         Long courseLectureId);
}
