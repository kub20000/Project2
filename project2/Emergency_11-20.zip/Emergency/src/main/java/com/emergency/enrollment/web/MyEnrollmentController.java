// src/main/java/com/emergency/enrollment/web/MyEnrollmentController.java
package com.emergency.enrollment.web;

import com.emergency.enrollment.domain.EnrollmentListItem;
import com.emergency.enrollment.service.EnrollmentService;
import com.emergency.user.web.LoginUser;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * 나의강의실 - 수강 관련 3개 페이지 컨트롤러
 *
 * 1) 수강목록      : /myPage/courseList      or /myPage/courseList.html
 * 2) 미수료        : /myPage/nonCompletion  or /myPage/nonCompletion.html
 * 3) 수료          : /myPage/completion     or /myPage/completion.html
 */
@Controller
@RequiredArgsConstructor
public class MyEnrollmentController {

    private final EnrollmentService enrollmentService;

    // LoginController 에서 로그인 성공 시 사용하는 세션 키와 동일해야 함
    private static final String LOGIN_USER_SESSION_KEY = "LOGIN_USER";

    /**
     * 공통: 세션에서 로그인 유저 꺼내기
     */
    private LoginUser getLoginUser(HttpSession session) {
        Object obj = session.getAttribute(LOGIN_USER_SESSION_KEY);
        if (obj instanceof LoginUser loginUser) {
            return loginUser;
        }
        return null;
    }

    /**
     * 공통: layout.html 기본 세팅
     */
    private void setupMyPage(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "MYCLASS");   // 나의강의실 메뉴 활성화
        model.addAttribute("showSidebar", true);       // 나의강의실 사이드바 사용
        model.addAttribute("contentTemplate", contentTemplate);

        model.addAttribute("pageCss", List.of(
//                "/css/courses_css/courses.css",
                "/css/myPage_css/courseList.css",
                "/css/myPage_css/coursePopUp.css",
                "/css/myPage_css/completion.css"


        ));
        // 필요 시 JS 추가
        // model.addAttribute("pageJs",  List.of("/fragments_js/mypage.js"));
    }

    /* --------------------------------------------------------------------
     * 1) 수강목록 (상태 전체)
     * ------------------------------------------------------------------ */
    @GetMapping({"/myPage/courseList", "/myPage/courseList.html"})
    public String courseList(@RequestParam(name = "mid", required = false) String midCategory,
                             @RequestParam(name = "keyword", required = false) String keyword, // [검색추가]
                             HttpSession session,
                             Model model) {

        LoginUser loginUser = getLoginUser(session);
        if (loginUser == null) {
            return "redirect:/login";
        }

        Long userId = loginUser.getUserId();

        List<EnrollmentListItem> enrollments =
                enrollmentService.getMyEnrollments(userId, null, midCategory);

        // [검색추가] 검색어가 있으면 제목에 keyword 포함된 것만 필터
        String trimmedKeyword = (keyword != null) ? keyword.trim() : null;
        if (trimmedKeyword != null && !trimmedKeyword.isEmpty()) {
            final String kw = trimmedKeyword;
            enrollments = enrollments.stream()
                    .filter(e -> e.getTitle() != null && e.getTitle().contains(kw))
                    .toList();
        }

        // 디버그 로그
        System.out.println("[MyEnrollmentController] /myPage/courseList userId="
                + userId + ", midCategory=" + midCategory
                + ", keyword=" + trimmedKeyword                              // [검색추가]
                + ", enrollments.size=" + (enrollments != null ? enrollments.size() : 0));

        // 수강목록 템플릿: templates/myPage/courseList.html
        setupMyPage(model, "수강 목록", "myPage/courseList");

        // 🔴 핵심: 템플릿에서 사용할 이름 두 개 다 넣어줌
        model.addAttribute("enrollments", enrollments);   // 새 이름
        model.addAttribute("courseList", enrollments);    // 예전 템플릿 호환용

        model.addAttribute("selectedMid", midCategory == null ? "" : midCategory);
        model.addAttribute("statusFilter", "ALL");
        model.addAttribute("keyword", trimmedKeyword == null ? "" : trimmedKeyword); // [검색추가]

        return "layout";
    }

    /* --------------------------------------------------------------------
     * 2) 미수료 강의 목록
     * ------------------------------------------------------------------ */
    @GetMapping({"/myPage/nonCompletion", "/myPage/nonCompletion.html"})
    public String nonCompletionList(@RequestParam(name = "mid", required = false) String midCategory,
                                    HttpSession session,
                                    Model model) {

        LoginUser loginUser = getLoginUser(session);
        if (loginUser == null) {
            return "redirect:/login";
        }

        Long userId = loginUser.getUserId();

        List<EnrollmentListItem> enrollments =
                enrollmentService.getMyEnrollments(userId, "미수료", midCategory);

        System.out.println("[MyEnrollmentController] /myPage/nonCompletion userId="
                + userId + ", midCategory=" + midCategory
                + ", enrollments.size=" + (enrollments != null ? enrollments.size() : 0));

        setupMyPage(model, "미수료 강의", "myPage/nonCompletion");

        // 상태/탭만 다르고 나머지 구조는 동일
        model.addAttribute("enrollments", enrollments);
        model.addAttribute("courseList", enrollments);    // 호환용

        model.addAttribute("selectedMid", midCategory == null ? "" : midCategory);
        model.addAttribute("statusFilter", "INCOMPLETE");

        return "layout";
    }

    /* --------------------------------------------------------------------
     * 3) 수료 강의 목록
     * ------------------------------------------------------------------ */
    @GetMapping({"/myPage/completion", "/myPage/completion.html"})
    public String completionList(@RequestParam(name = "mid", required = false) String midCategory,
                                 HttpSession session,
                                 Model model) {

        LoginUser loginUser = getLoginUser(session);
        if (loginUser == null) {
            return "redirect:/login";
        }

        Long userId = loginUser.getUserId();

        List<EnrollmentListItem> enrollments =
                enrollmentService.getMyEnrollments(userId, "수료", midCategory);

        System.out.println("[MyEnrollmentController] /myPage/completion userId="
                + userId + ", midCategory=" + midCategory
                + ", enrollments.size=" + (enrollments != null ? enrollments.size() : 0));

        setupMyPage(model, "수료 강의", "myPage/completion");

        model.addAttribute("enrollments", enrollments);
        model.addAttribute("courseList", enrollments);    // 호환용

        model.addAttribute("selectedMid", midCategory == null ? "" : midCategory);
        model.addAttribute("statusFilter", "COMPLETED");

        return "layout";
    }

    /* --------------------------------------------------------------------
     * 4) 강의 재생 팝업 (AJAX로 불러오는 모달 fragment)
     * ------------------------------------------------------------------ */
    @GetMapping("/myPage/lecturePopup")
    public String lecturePopup(@RequestParam("enrollmentId") Long enrollmentId,
                               @RequestParam("courseId") Long courseId,
                               Model model) {

        // 일단은 ID만 전달해 두고, 나중에 필요하면
        // enrollmentId / courseId 로 강의·차시·진도 정보 조회해서 채워 넣으면 됨.
        model.addAttribute("enrollmentId", enrollmentId);
        model.addAttribute("courseId", courseId);

        // templates/myPage/coursePopUp.html 안의 lecturePopup fragment만 렌더링해서 반환
        return "myPage/coursePopUp :: lecturePopup";
    }
}

