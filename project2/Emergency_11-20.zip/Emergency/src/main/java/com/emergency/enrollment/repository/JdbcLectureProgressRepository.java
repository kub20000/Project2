// src/main/java/com/emergency/enrollment/repository/JdbcLectureProgressRepository.java
package com.emergency.enrollment.repository;

import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * lecture_progress 테이블에 대한 JdbcTemplate 구현체
 */
@Repository
@RequiredArgsConstructor
public class JdbcLectureProgressRepository implements LectureProgressRepository {

    private final JdbcTemplate jdbc;

    @Override
    public void insertInitial(Long enrollmentId, Long courseLectureId) {
        String sql = """
                INSERT INTO lecture_progress
                    (enrollment_id, course_lecture_id, watch_sec, completed)
                VALUES (?, ?, 0, 0)
                """;
        jdbc.update(sql, enrollmentId, courseLectureId);
    }

    // [추가] 시청 구간/완료 여부 저장
    @Override
    public void updateProgress(Long enrollmentId,
                               Long courseLectureId,
                               int watchSec,
                               boolean completed) {

        String sql = """
                UPDATE lecture_progress
                   SET watch_sec = ?,
                       completed = ?
                 WHERE enrollment_id = ?
                   AND course_lecture_id = ?
                """;

        jdbc.update(sql,
                watchSec,
                completed ? 1 : 0,
                enrollmentId,
                courseLectureId);
    }

    // [추가] 이어보기용 마지막 시청 구간 조회
    @Override
    public Integer findWatchSec(Long enrollmentId, Long courseLectureId) {
        String sql = """
                SELECT watch_sec
                  FROM lecture_progress
                 WHERE enrollment_id = ?
                   AND course_lecture_id = ?
                """;

        return jdbc.query(sql,
                        (rs, rowNum) -> rs.getInt("watch_sec"),
                        enrollmentId, courseLectureId)
                .stream()
                .findFirst()
                .orElse(null);
    }
}
