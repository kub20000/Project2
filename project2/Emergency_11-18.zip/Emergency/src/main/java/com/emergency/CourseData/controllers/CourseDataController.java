package com.emergency.CourseData.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class CourseDataController {

    /** 공통: 교육자료 페이지 기본 세팅 */
    private void setupDataPage(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "COURSE"); // 같은 메뉴 그룹
        model.addAttribute("showSidebar", true);
        model.addAttribute("contentTemplate", contentTemplate);

        model.addAttribute("pageCss", List.of(
                "/css/fragments_css/common.css",
                "/css/fragments_css/components.css",
                "/css/courses_css/courses.css",
                "/css/courses_css/about.css"
        ));
        model.addAttribute("pageJs", List.of("/fragments_js/pageNationC.JS"));
    }

    // 교육자료 - 전체
    @GetMapping({"/courses/data", "/courses/data.html"})
    public String dataAll(Model model) {
        setupDataPage(model, "교육 자료", "courses/data");
        return "layout";
    }

    // 교육자료 - 출혈
    @GetMapping({"/courses/data1", "/courses/data1.html"})
    public String dataBleeding(Model model) {
        setupDataPage(model, "교육 자료 - 출혈", "courses/data1");
        return "layout";
    }

    // 교육자료 - 기도막힘
    @GetMapping({"/courses/data2", "/courses/data2.html"})
    public String dataAirway(Model model) {
        setupDataPage(model, "교육 자료 - 기도막힘", "courses/data2");
        return "layout";
    }

    // 교육자료 - 심정지
    @GetMapping({"/courses/data3", "/courses/data3.html"})
    public String dataCardiac(Model model) {
        setupDataPage(model, "교육 자료 - 심정지", "courses/data3");
        return "layout";
    }

    // 교육자료 - 화상
    @GetMapping({"/courses/data4", "/courses/data4.html"})
    public String dataBurn(Model model) {
        setupDataPage(model, "교육 자료 - 화상", "courses/data4");
        return "layout";
    }
}
