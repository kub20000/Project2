package com.emergency.pages.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class NewsController {

    private void setupNews(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "NEWS");
        model.addAttribute("showSidebar", true); // 소식센터 사이드바

        model.addAttribute("contentTemplate", contentTemplate);

        model.addAttribute("pageCss", List.of("/css/pages_css/news.css"));
        model.addAttribute("pageJs", List.of("/fragments_js/pageNationC.JS"));
    }

    // 공지사항 목록
    @GetMapping({"/news/notice", "/news/notice.html"})
    public String noticeList(Model model) {
        // templates/pages/notice.html
        setupNews(model, "공지사항", "pages/notice");
        return "layout";
    }

    // 공지사항 상세
    @GetMapping({"/news/noticeDetail", "/news/noticeDetail.html"})
    public String noticeDetail(Model model) {
        // templates/pages/noticeDetail.html
        setupNews(model, "공지사항 상세", "pages/noticeDetail");
        return "layout";
    }

    // FAQ
    @GetMapping({"/news/faq", "/news/faq.html"})
    public String faq(Model model) {
        // templates/pages/faq.html
        setupNews(model, "FAQ", "pages/faq");
        return "layout";
    }

    // 보도자료 목록
    @GetMapping({"/news/news", "/news/news.html"})
    public String newsList(Model model) {
        // templates/pages/news.html
        setupNews(model, "보도자료", "pages/news");
        return "layout";
    }

    // 보도자료 상세
    @GetMapping({"/news/newsDetail", "/news/newsDetail.html"})
    public String newsDetail(Model model) {
        // templates/pages/newsDetail.html
        setupNews(model, "보도자료 상세", "pages/newsDetail");
        return "layout";
    }
}
