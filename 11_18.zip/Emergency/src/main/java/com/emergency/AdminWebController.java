package com.emergency;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdminWebController {

    @GetMapping("/")  // 루트 경로
    public String home() {
        return "adminHome";  // templates/index.html 로 연결
    }
    @GetMapping("adminHome")
    public String adminHome() {
        return "adminHome";
    }

    @GetMapping("adminUser/adminUser")
    public String adminUser() {
        return "adminUser/adminUser";
    }

    @GetMapping("adminCourse/adminCourseList")
    public String adminCourseList() {
        return "adminCourse/adminCourseList";
    }

    @GetMapping("adminCourse/adminCourseAdd")
    public String adminCourseAdd() {
        return "adminCourse/adminCourseAdd";
    }

    @GetMapping("adminEdu/adminEdu")
    public String adminEdu() {
        return "adminEdu/adminEdu";
    }
    @GetMapping("adminEdu/adminEduAdd")
    public String adminEduAdd() {
        return "adminEdu/adminEduAdd";
    }

    @GetMapping("adminNotice/adminNotice")
    public String adminNotice() {
        return "adminNotice/adminNotice";
    }

    @GetMapping("adminNotice/adminNoticeAdd")
    public String adminNoticeAdd() {
        return "adminNotice/adminNoticeAdd";
    }

    @GetMapping("adminInquiry/adminInquiry")
    public String adminInquiry() {
        return "adminInquiry/adminInquiry";
    }
    @GetMapping("adminPress/adminPressRelease")
    public String adminPress() {
        return "adminPress/adminPressRelease";
    }
    @GetMapping("adminPress/adminPressAdd")
    public String adminPressAdd() {
        return "adminPress/adminPressAdd";
    }

}