
// 요소
const tbody = document.querySelector("#admin_courseList_table tbody");
const courseTotalCount = document.getElementById("admin_tot_cnt");
// const rowSelect = document.getElementById("admin_row_select");


// 1️⃣ 페이지 로드시 DB 데이터 불러오기
async function loadCourseList() {
    try {
        const res = await fetch("/admin/api/courses");
        courseList = await res.json();

        renderTable(currentPage);
        renderPagination(courseList.length);

    } catch (err) {
        console.error("강의 리스트 로드 실패:", err);
    }
}


// 2️⃣ 테이블 렌더링
function renderTable(page) {
    tbody.innerHTML = "";

    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const pageData = courseList.slice(start, end);

    pageData.forEach((c, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${start + idx + 1}</td>
      <td><img src="${c.image_path}"></td>
      <td>
        <div class="course_title_box">
          <p class="course_category">[${c.top_category} / ${c.mid_category}]</p>
          <a href="/admin/course/edit?id=${c.course_id}" class="course_link">${c.title}</a>

        </div>
      </td>
      <td>관리자</td>
      <td>${c.reg_date}</td>
      <td><button class="admin_delete_btn" data-course-id="${c.course_id}">삭제</button></td>
    `;
        tbody.appendChild(tr);
    });

    courseTotalCount.textContent = courseList.length;
    attachDeleteEvents();
}


// 3️⃣ 삭제 버튼 처리
function attachDeleteEvents() {
    document.querySelectorAll(".admin_delete_btn").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
            const courseId = e.target.dataset.courseId;

            if (!confirm("정말 삭제하시겠습니까?")) return;

            try {
                await fetch(`/admin/api/course/${courseId}`, { method: "DELETE" });
                alert("삭제되었습니다.");

                // 클라이언트에서 제거
                courseList = courseList.filter(c => c.course_id != courseId);

                renderTable(currentPage);
                renderPagination(courseList.length);

            } catch (err) {
                console.error(err);
                alert("삭제 중 오류 발생");
            }
        });
    });
}


// 4️⃣ 행 개수 변경
rowSelect.addEventListener("change", function () {
    rowsPerPage = parseInt(this.value);
    currentPage = 1;
    renderTable(currentPage);
    renderPagination(courseList.length);
});


// 5️⃣ 페이지 변경
function changePage(page) {
    currentPage = page;
    renderTable(currentPage);
    renderPagination(courseList.length);
}


// 6️⃣ 최종 실행
loadCourseList();
