// 사이드바 모션
 document.querySelectorAll(".sidebar-item").forEach(item => {
    item.addEventListener("click", () => {
      const next = item.nextElementSibling;
      const isSubmenu = next && next.classList.contains("submenu");

      // 다른 열린 메뉴 닫기 (선택적)
      document.querySelectorAll(".submenu.show").forEach(openMenu => {
        if (openMenu !== next) {
          openMenu.classList.remove("show");
          openMenu.previousElementSibling?.classList.remove("active");
        }
      });

      // 현재 메뉴 토글
      if (isSubmenu) {
        next.classList.toggle("show");
        item.classList.toggle("active");
      }
    });
  });


   //탭버튼
  const tabs = document.querySelectorAll(".tab");
const tabContents = document.querySelectorAll(".tab-content");

tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => {
    
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");

    
    tabContents.forEach(c => c.classList.remove("active"));
    tabContents[index].classList.add("active");
  });
});
// 초기 페이지 로드
  showPage(1);


//사이드바 엑티브

 document.addEventListener('DOMContentLoaded', () => {
  const sidebarItems = document.querySelectorAll('.sidebar-item');

  // ✅ 초기 active 상태 유지 (페이지 로드시)
  sidebarItems.forEach(item => {
    const submenu = item.nextElementSibling;
    if (item.classList.contains('active') && submenu && submenu.classList.contains('submenu')) {
      submenu.classList.add('show');
    }
  });

  sidebarItems.forEach(item => {
    const submenu = item.nextElementSibling;

    if (submenu && submenu.classList.contains('submenu')) {
      item.addEventListener('click', () => {
        // 이미 active면 다시 클릭해도 유지 (닫히지 않음)
        if (item.classList.contains('active')) return;

        // 다른 항목 비활성화
        sidebarItems.forEach(i => {
          i.classList.remove('active');
          const s = i.nextElementSibling;
          if (s && s.classList.contains('submenu')) {
            s.classList.remove('show');
          }
        });

        // 클릭한 항목만 활성화
        item.classList.add('active');
        submenu.classList.add('show');
      });
    }
  });

  // === 서브메뉴 클릭 처리 ===
  const submenuLinks = document.querySelectorAll('.submenu a');
  submenuLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.stopPropagation();
      submenuLinks.forEach(a => a.classList.remove('current'));
      e.target.classList.add('current');
    });
  });
});







