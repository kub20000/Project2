 // 사이드바 모션
 document.querySelectorAll(".sidebar-item").forEach(item => {
    item.addEventListener("click", () => {
      const next = item.nextElementSibling;
      const isSubmenu = next && next.classList.contains("submenu");

      // 다른 열린 메뉴 닫기 (선택적)
      document.querySelectorAll(".submenu.show").forEach(openMenu => {
        if (openMenu !== next) {
          openMenu.classList.remove("show");
          openMenu.previousElementSibling?.classList.remove("active");
        }
      });

      // 현재 메뉴 토글
      if (isSubmenu) {
        next.classList.toggle("show");
        item.classList.toggle("active");
      }
    });
  });


   //탭버튼
  const tabs = document.querySelectorAll(".tab");
const tabContents = document.querySelectorAll(".tab-content");

tabs.forEach((tab, index) => {
  tab.addEventListener("click", () => {
    
    tabs.forEach(t => t.classList.remove("active"));
    tab.classList.add("active");

    
    tabContents.forEach(c => c.classList.remove("active"));
    tabContents[index].classList.add("active");
  });
});