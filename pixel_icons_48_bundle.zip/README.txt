Icons normalized to 48x48 canvas (no scaling).
Atlas: sprite_atlas_48.png
JSON:  sprite_atlas_48.json
Columns: 10, Rows: 9, Count: 90
Filenames: item_001.png ... item_090.png
