package com.emergency.exam.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class ExamController {

    @GetMapping({"/exam", "/exam/exam", "/exam/exam.html"})
    public String exam(Model model) {
        model.addAttribute("pageTitle", "시험 응시");
        // 시험은 나의 강의실 쪽에서 들어온다고 보고
        model.addAttribute("activeMenu", "MYCLASS");
        model.addAttribute("showSidebar", true); // 시험은 풀스크린 느낌으로

        // templates/pages/exam.html
        model.addAttribute("contentTemplate", "pages/exam");

        model.addAttribute("pageCss", List.of("/css/exam_css/exam.css"));
        model.addAttribute("pageJs", List.of());

        return "layout";
    }
}
