package com.emergency.myPage.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class MyPageController {

    private void setupMyPage(Model model, String title, String contentTemplate) {
        model.addAttribute("pageTitle", title);
        model.addAttribute("activeMenu", "MYCLASS");
        model.addAttribute("showSidebar", true); // 나의 강의실 사이드바

        model.addAttribute("contentTemplate", contentTemplate);

        model.addAttribute("pageCss", List.of(
                "/css/join_css/join.css",
                "/css/myPage_css/my.css"
        ));
        model.addAttribute("pageJs", List.of("/fragments_js/pageNationC.JS","/fragments_js/inoModal.js"
        ,"/fragments_js/coursePopUp.js","/fragments_js/courseList.js"
        ));
    }

    @GetMapping({"/myPage/myStudy", "/myPage/myStudy.html"})
    public String myStudy(Model model) {
        // templates/pages/myStudy.html
        setupMyPage(model, "나의 학습활동", "myPage/myStudy");
        return "layout";
    }

    @GetMapping({"/myPage/courseList", "/myPage/courseList.html"})
    public String courseList(Model model) {
        // templates/pages/courseList.html
        setupMyPage(model, "수강 신청 내역", "myPage/courseList");
        return "layout";
    }

    @GetMapping({"/myPage/completion", "/myPage/completion.html"})
    public String completion(Model model) {
        // templates/pages/completion.html
        setupMyPage(model, "수료 강의", "myPage/completion");
        return "layout";
    }

    @GetMapping({"/myPage/nonCompletion", "/myPage/nonCompletion.html"})
    public String nonCompletion(Model model) {
        // templates/pages/nonCompletion.html
        setupMyPage(model, "미수료 강의", "myPage/nonCompletion");
        return "layout";
    }

    @GetMapping({"/myPage/infoModify", "/myPage/infoModify.html"})
    public String infoModify(Model model) {
        // templates/pages/infoModify.html
        setupMyPage(model, "회원 정보 수정", "myPage/infoModify");
        return "layout";
    }

    @GetMapping({"/myPage/question", "/myPage/question.html"})
    public String questionList(Model model) {
        // templates/pages/question.html
        setupMyPage(model, "문의사항", "myPage/question");
        return "layout";
    }

    @GetMapping({"/myPage/questionDetail", "/myPage/questionDetail.html"})
    public String questionDetail(Model model) {
        // templates/pages/questionDetail.html
        setupMyPage(model, "문의사항 상세", "myPage/questionDetail");
        return "layout";
    }

    @GetMapping({"/myPage/uploadQuestion", "/myPage/uploadQuestion.html"})
    public String uploadQuestion(Model model) {
        // templates/pages/uploadQuestion.html
        setupMyPage(model, "문의사항 등록", "myPage/uploadQuestion");
        return "layout";
    }

    // 필요하면 강의 설명 팝업도 매핑
    @GetMapping({"/myPage/coursePopUp", "/myPage/coursePopUp.html"})
    public String coursePopUp(Model model) {
        // templates/pages/coursePopUp.html
        setupMyPage(model, "강의 상세", "myPage/coursePopUp");
        return "layout";
    }
}
