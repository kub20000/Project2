package com.emergency.home.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class HomeController {

    @GetMapping({"/", "/home", "/home.html"})
    public String home(Model model) {

        model.addAttribute("pageTitle", "메인 홈");
        model.addAttribute("activeMenu", "HOME");
        model.addAttribute("showSidebar", false);

        // 🔥 여기 이름과 템플릿 경로가 딱 맞아야 함 (home.html)
        model.addAttribute("contentTemplate", "home");

        // 홈 전용 CSS (static/home.css)
        model.addAttribute("pageCss", List.of("css/home.css"));
        model.addAttribute("pageJs", List.of("fragments_js/home.js"));

        return "layout";  // templates/layout.html
    }
}
