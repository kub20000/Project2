package com.emergency.docs.web;

import com.emergency.docs.domain.Material;
import com.emergency.docs.service.MaterialService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.util.UriUtils;

import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.springframework.http.HttpStatus.NOT_FOUND;

@Controller
@RequestMapping("/materials")
@RequiredArgsConstructor
public class MaterialFileController {

    private final MaterialService materialService;

    // MaterialService에서 파일 저장할 때 쓰던 것과 같은 경로
    @Value("${docs.storage.base-path}")
    private String storageBasePath;

    private Path getFilePath(Material material) {
        // pdf_path 에 상대 경로가 들어 있다고 가정 (예: "2025/11/18/uuid.pdf")
        return Paths.get(storageBasePath)
                .resolve(material.getPdfPath())
                .normalize();
    }

    /** PDF 다운로드 */
    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable Long id) throws MalformedURLException {
        Material material = materialService.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND));

        Path path = getFilePath(material);
        if (!Files.exists(path)) {
            throw new ResponseStatusException(NOT_FOUND);
        }

        UrlResource resource = new UrlResource(path.toUri());
        String fileName = path.getFileName().toString();
        String encodedFileName = UriUtils.encode(fileName, StandardCharsets.UTF_8);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + encodedFileName + "\"")
                .body(resource);
    }

    /** PDF 미리보기 (브라우저 내장 뷰어에서 열기) */
    @GetMapping("/{id}/preview")
    public ResponseEntity<Resource> preview(@PathVariable Long id) throws MalformedURLException {
        Material material = materialService.findById(id)
                .orElseThrow(() -> new ResponseStatusException(NOT_FOUND));

        Path path = getFilePath(material);
        if (!Files.exists(path)) {
            throw new ResponseStatusException(NOT_FOUND);
        }

        UrlResource resource = new UrlResource(path.toUri());
        String fileName = path.getFileName().toString();
        String encodedFileName = UriUtils.encode(fileName, StandardCharsets.UTF_8);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                // inline 으로 보내면 브라우저에서 바로 미리보기
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + encodedFileName + "\"")
                .body(resource);
    }
}

