package com.emergency.press.web;

import com.emergency.press.domain.PressRelease;
import com.emergency.press.service.PressReleaseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/news") // ★ 여기 주의
@RequiredArgsConstructor
public class PressReleaseFrontController {

    private final PressReleaseService pressReleaseService;

    @GetMapping            // ★ 그래서 여기 경로는 "/news" 하나만!
    public String list(@RequestParam(name = "page", defaultValue = "1") int page,
                       @RequestParam(name = "size", defaultValue = "10") int size,
                       @RequestParam(name = "q", required = false) String keyword,
                       Model model) {

        int totalCount = pressReleaseService.count(keyword);
        if (page < 1) page = 1;

        int totalPages = (int) Math.ceil((double) totalCount / size);
        if (totalPages > 0 && page > totalPages) {
            page = totalPages;
        }

        List<PressRelease> list = totalCount > 0
                ? pressReleaseService.findPage(page, size, keyword)
                : List.of();

        List<Integer> pageNumbers = totalPages > 0
                ? java.util.stream.IntStream.rangeClosed(1, totalPages)
                .boxed().toList()
                : List.of();

        // ★ 이 여섯 개가 지금 템플릿에서 사용하는 값들
        model.addAttribute("pressReleases", list);
        model.addAttribute("totalCount", totalCount);
        model.addAttribute("page", page);
        model.addAttribute("size", size);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("pageNumbers", pageNumbers);
        model.addAttribute("keyword", keyword);

        // layout 공통
        model.addAttribute("pageTitle", "보도자료");
        model.addAttribute("activeMenu", "NEWS");
        model.addAttribute("showSidebar", true);
        model.addAttribute("contentTemplate", "pages/news");
        model.addAttribute("pageCss", List.of("/css/pages_css/news.css"));
        return "layout";
    }

    /** 상세페이지 */
    @GetMapping("/{id}")
    public String detail(@PathVariable("id") Long id, Model model) {

        PressRelease press = pressReleaseService.findById(id);
        if (press == null) {
            // 글 없으면 목록으로
            return "redirect:/news";
        }

        PressRelease prev = pressReleaseService.findPrev(id);
        PressRelease next = pressReleaseService.findNext(id);

        model.addAttribute("press", press);
        model.addAttribute("prevPress", prev);
        model.addAttribute("nextPress", next);

        // layout 공통
        model.addAttribute("pageTitle", "보도자료 상세");
        model.addAttribute("activeMenu", "NEWS");
        model.addAttribute("showSidebar", true);
        model.addAttribute("contentTemplate", "pages/newsDetail"); // ★ newsDetail.html

        model.addAttribute("pageCss", List.of(
                "/css/fragments_css/common.css",
                "/css/fragments_css/components.css",
                "/css/pages_css/news.css"
        ));
        model.addAttribute("pageJs", List.of());

        return "layout";
    }
}
