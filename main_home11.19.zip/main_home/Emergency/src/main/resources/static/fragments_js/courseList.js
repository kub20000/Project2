document.addEventListener('DOMContentLoaded', () => {

    const myJoinedRoomIds = [1, 4, 7]; // (원본 코드에 없지만 필요 시 사용 가능)

    document.querySelectorAll('.play-btn').forEach(btn => {
        btn.addEventListener('click', async () => {

            // 팝업이 아직 없으면 fetch로 불러오기
            if (!document.getElementById('lecturePopup')) {
                const res = await fetch('coursePopUp.html');
                const html = await res.text();
                document.body.insertAdjacentHTML('beforeend', html);
            }

            const popup = document.getElementById('lecturePopup');
            popup.style.display = 'flex';
            document.body.style.overflow = 'hidden'; // 배경 스크롤 막기

            initLecturePopup(); // 팝업 이벤트 초기화
        });
    });

    // 팝업 내부 이벤트 초기화 함수
    function initLecturePopup() {
        const popup = document.getElementById('lecturePopup');
        if (!popup) return;

        // 닫기 버튼
        const closeBtn = popup.querySelector('.close-btn');
        closeBtn.addEventListener('click', () => {
            popup.style.display = 'none';
            document.body.style.overflow = 'auto';
        });

        // 탭 전환
        const tabs = popup.querySelectorAll('.tab-btn');
        const contents = popup.querySelectorAll('.tab-content');
        const controlBtn = popup.querySelector('.control-btn');

        tabs.forEach(btn => {
            btn.addEventListener('click', () => {
                tabs.forEach(b => b.classList.remove('active'));
                contents.forEach(c => c.classList.remove('active'));
                btn.classList.add('active');
                popup.querySelector('#' + btn.dataset.tab).classList.add('active');

                // 탭별 버튼 텍스트 변경
                if (btn.dataset.tab === 'list') controlBtn.textContent = '수강 완료';
                else if (btn.dataset.tab === 'memo') controlBtn.textContent = '저장';
                else if (btn.dataset.tab === 'materials') controlBtn.textContent = '다운로드';
            });
        });

        // 목차 클릭 시 강조
        popup.querySelectorAll('.lecture-list li').forEach((item, index) => {
            item.addEventListener('click', () => {
                popup.querySelectorAll('.lecture-list li').forEach(i => i.classList.remove('active'));
                item.classList.add('active');
            });
        });
    }
});