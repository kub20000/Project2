// 닫기 버튼
document.getElementById('closePopup')?.addEventListener('click', () => {
    document.getElementById('lecturePopup').style.display = 'none';
});

// 탭 전환
const tabs = document.querySelectorAll('.tab-btn');
const contents = document.querySelectorAll('.tab-content');
const controlBtn = document.querySelector('.control-btn');

tabs.forEach(btn => {
    btn.addEventListener('click', () => {
        tabs.forEach(b => b.classList.remove('active'));
        contents.forEach(c => c.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById(btn.dataset.tab).classList.add('active');

        if (btn.dataset.tab === 'list') {
            controlBtn.textContent = '수강 완료';
        } else if (btn.dataset.tab === 'memo') {
            controlBtn.textContent = '저장';
        } else if (btn.dataset.tab === 'materials') {
            controlBtn.textContent = '다운로드';
        }
    });
});

// 목차 클릭 시 강조
document.querySelectorAll('.lecture-list li').forEach((item, index) => {
    item.addEventListener('click', () => {
        document.querySelectorAll('.lecture-list li').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        console.log(`목차 ${index + 1} 클릭됨`);
    });
});