document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("joinForm");
    const cancelBtn = document.querySelector(".cancel");
    const resetBtn = document.querySelector(".check-btn");

    // 비밀번호 관련 요소
    const newPwField = document.getElementById("newPassword").closest(".field");
    const pwCheckField = document.getElementById("passwordCheck").closest(".field");

    // 기본적으로 비밀번호 관련 입력창 숨김
    newPwField.style.display = "none";
    pwCheckField.style.display = "none";

    // "비밀번호 재설정" 클릭 시 토글
    resetBtn.addEventListener("click", () => {
        const isHidden = newPwField.style.display === "none";
        newPwField.style.display = isHidden ? "block" : "none";
        pwCheckField.style.display = isHidden ? "block" : "none";
        resetBtn.textContent = isHidden ? "비밀번호 재설정 취소" : "비밀번호 재설정";
    });

    // 비밀번호 유효성 검사
    const newPw = document.getElementById("newPassword");
    const pwCheck = document.getElementById("passwordCheck");
    const pwCheckHint = pwCheck.nextElementSibling;

    newPw.addEventListener("input", () => {
        const pwPattern = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
        const hint = newPw.nextElementSibling;
        if (newPw.value.trim() === "") {
            hint.textContent = "비밀번호를 입력해주세요.";
            hint.style.color = "red";
        } else if (pwPattern.test(newPw.value)) {
            hint.textContent = "사용 가능한 비밀번호입니다.";
            hint.style.color = "green";
        } else {
            hint.textContent = "영문, 숫자, 특수문자 포함 8자리 이상이어야 합니다.";
            hint.style.color = "red";
        }
    });

    pwCheck.addEventListener("input", () => {
        if (pwCheck.value === "") {
            pwCheckHint.textContent = "비밀번호를 다시 입력해주세요.";
            pwCheckHint.style.color = "red";
        } else if (pwCheck.value === newPw.value) {
            pwCheckHint.textContent = "비밀번호가 일치합니다.";
            pwCheckHint.style.color = "green";
        } else {
            pwCheckHint.textContent = "비밀번호가 일치하지 않습니다.";
            pwCheckHint.style.color = "red";
        }
    });

    // 전화번호 하이픈 자동 삽입
    const phone = document.getElementById("phone");
    const phoneHint = phone.nextElementSibling;

    phone.addEventListener("input", () => {
        let value = phone.value.replace(/[^0-9]/g, "");

        if (value.length < 4) {
            phone.value = value;
        } else if (value.length < 8) {
            phone.value = value.replace(/(\d{3})(\d{1,4})/, "$1-$2");
        } else {
            phone.value = value.replace(/(\d{3})(\d{4})(\d{1,4})/, "$1-$2-$3");
        }

        if (value === "") {
            phoneHint.textContent = "전화번호를 입력해주세요.";
            phoneHint.style.color = "red";
        } else if (/^010-\d{4}-\d{4}$/.test(phone.value)) {
            phoneHint.textContent = "올바른 전화번호 형식입니다.";
            phoneHint.style.color = "green";
        } else {
            phoneHint.textContent = "올바른 전화번호 형식이 아닙니다. (예: 010-1234-5678)";
            phoneHint.style.color = "red";
        }
    });

    // 이메일 유효성 검사
    const email = document.getElementById("email");
    const emailHint = email.nextElementSibling;

    email.addEventListener("input", () => {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (email.value.trim() === "") {
            emailHint.textContent = "이메일을 입력해주세요.";
            emailHint.style.color = "red";
        } else if (emailPattern.test(email.value)) {
            emailHint.textContent = "올바른 이메일 형식입니다.";
            emailHint.style.color = "green";
        } else {
            emailHint.textContent = "올바른 이메일 형식이 아닙니다.";
            emailHint.style.color = "red";
        }
    });

    // 폼 제출 시 검사
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        if (newPwField.style.display !== "none") {
            if (newPw.value.trim() === "" || pwCheck.value.trim() === "") {
                alert("비밀번호를 모두 입력해주세요.");
                return;
            }
            if (newPw.value !== pwCheck.value) {
                alert("비밀번호가 일치하지 않습니다.");
                return;
            }
        }

        if (!/^010-\d{4}-\d{4}$/.test(phone.value)) {
            alert("전화번호 형식이 올바르지 않습니다.");
            return;
        }

        if (!email.value.trim()) {
            alert("이메일을 입력해주세요.");
            return;
        }

        alert("회원정보가 수정되었습니다.");
    });

    // 닫기 버튼
    cancelBtn.addEventListener("click", function () {
        if (confirm("변경사항을 저장하지 않고 닫으시겠습니까?")) {
            history.back();
        }
    });
});
