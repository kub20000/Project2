using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneStateManager : MonoBehaviour
{
    public static SceneStateManager instance;

    private Vector3 savedPlayerPosition;
    private Vector3 savedPatientPosition;
    private Vector3 savedCameraPosition;

    private bool playerSaved = false;
    private bool patientSaved = false;
    private bool cameraSaved = false;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
            return;
        }
    }

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    // �� �ε� �� ����
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (scene.name == "CPR1") // Ư�� ���� �����ϰ� �ʹٸ� ����
        {
            // Player ����
            if (playerSaved)
            {
                GameObject player = GameObject.Find("Player");
                if (player != null)
                {
                    player.transform.position = savedPlayerPosition;
                    Debug.Log("Player ��ġ ����: " + savedPlayerPosition);
                }
            }

            // Patient ����
            if (patientSaved)
            {
                GameObject patient = GameObject.Find("Patient");
                if (patient != null)
                {
                    patient.transform.position = savedPatientPosition;
                    Debug.Log("Patient ��ġ ����: " + savedPatientPosition);
                }
            }

            // Camera ����
            if (cameraSaved)
            {
                Camera mainCam = Camera.main;
                if (mainCam != null)
                {
                    mainCam.transform.position = savedCameraPosition;
                    Debug.Log("ī�޶� ��ġ ����: " + savedCameraPosition);
                }
            }
        }
    }

    // ���� �Լ� (Player / Patient / Camera �ڵ� �ν�)
    public void SaveState(GameObject target)
    {
        if (target == null)
        {
            Debug.LogWarning("SaveState�� null�� ���Խ��ϴ�.");
            return;
        }

        string name = target.name;

        if (name == "Player")
        {
            savedPlayerPosition = target.transform.position;
            playerSaved = true;
            Debug.Log("Player ��ġ ����: " + savedPlayerPosition);
        }
        else if (name == "Patient")
        {
            savedPatientPosition = target.transform.position;
            patientSaved = true;
            Debug.Log("Patient ��ġ ����: " + savedPatientPosition);
        }
        else if (name.Contains("Camera"))
        {
            savedCameraPosition = target.transform.position;
            cameraSaved = true;
            Debug.Log("Camera ��ġ ����: " + savedCameraPosition);
        }
        else
        {
            Debug.Log("SaveState: ����� Player, Patient, Camera�� �ƴմϴ�. ��� �̸�: " + name);
        }
    }

    // ���� ����
    public void SaveAll()
    {
        GameObject player = GameObject.Find("Player");
        if (player != null)
        {
            savedPlayerPosition = player.transform.position;
            playerSaved = true;
        }

        GameObject patient = GameObject.Find("Patient");
        if (patient != null)
        {
            savedPatientPosition = patient.transform.position;
            patientSaved = true;
        }

        Camera mainCam = Camera.main;
        if (mainCam != null)
        {
            savedCameraPosition = mainCam.transform.position;
            cameraSaved = true;
        }

        Debug.Log("Player, Patient, Camera ��ġ ���� �Ϸ�");
    }

    // �ʱ�ȭ
    public void ClearSaved()
    {
        playerSaved = false;
        patientSaved = false;
        cameraSaved = false;

        savedPlayerPosition = Vector3.zero;
        savedPatientPosition = Vector3.zero;
        savedCameraPosition = Vector3.zero;

        Debug.Log("����� ���� �ʱ�ȭ��.");
    }
}
