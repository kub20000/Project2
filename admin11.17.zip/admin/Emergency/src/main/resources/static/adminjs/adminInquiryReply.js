document.addEventListener("DOMContentLoaded", () => {
    const replyForm = document.getElementById("admin_inq_reply_form");
    const replyContent = document.getElementById("replyContent");
    const replyList = document.getElementById("admin_inq_reply_list");
    const inqFile = document.getElementById("inqFile");

    /* ===== 첨부파일 표시 ===== */
    // 실제 파일 정보 예시 (없을 경우 null)
    const attachedFile = null;
    // const attachedFile = { name: "login_error.png", url: "upload/login_error.png" };

    if (attachedFile && attachedFile.url) {
        inqFile.innerHTML = `
      <a href="${attachedFile.url}" target="_blank" class="file_link">
        <span class="file_icon">📎</span>${attachedFile.name}
      </a>
    `;
    } else {
        inqFile.innerHTML = `<span class="no_file_text">첨부된 파일이 없습니다.</span>`;
    }

    /* ===== 답변 등록 ===== */
    replyForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const content = replyContent.value.trim();
        if (!content) {
            alert("답변 내용을 입력하세요.");
            return;
        }

        const now = new Date();
        const dateStr = now.toLocaleString("ko-KR", {
            year: "numeric",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
        });

        const replyItem = document.createElement("div");
        replyItem.classList.add("admin_inq_reply_item");
        replyItem.innerHTML = `
      <div class="reply_header">
        <div class="reply_left">
          <strong class="reply_author">관리자</strong>
            <div class="reply_btns">
                <button class="reply_edit_btn">수정</button>
                <button class="reply_delete_btn">삭제</button>
            </div>
        </div>
        <div class="reply_right">
          <span class="reply_date">${dateStr}</span>
        </div>
      </div>
      <div class="reply_content">${content}</div>
    `;

        replyList.prepend(replyItem);
        replyContent.value = "";
    });

    /* ===== 수정 / 삭제 ===== */
    replyList.addEventListener("click", (e) => {
        const target = e.target;

        // 삭제
        if (target.classList.contains("reply_delete_btn")) {
            if (confirm("정말 삭제하시겠습니까?")) {
                target.closest(".admin_inq_reply_item").remove();
            }
        }

        // 수정
        if (target.classList.contains("reply_edit_btn")) {
            const replyItem = target.closest(".admin_inq_reply_item");
            const contentDiv = replyItem.querySelector(".reply_content");

            // 이미 수정 중이면 무시
            if (replyItem.querySelector(".reply_edit_area")) return;

            const oldText = contentDiv.textContent;

            // textarea로 변환
            const textarea = document.createElement("textarea");
            textarea.classList.add("reply_edit_area");
            textarea.value = oldText;
            contentDiv.replaceWith(textarea);

            // 버튼 전환
            target.textContent = "저장";
            target.classList.add("save_mode");

            // 저장 이벤트 (한 번만 실행)
            const saveHandler = () => {
                const newText = textarea.value.trim() || oldText;

                const newContent = document.createElement("div");
                newContent.classList.add("reply_content");
                newContent.textContent = newText;

                textarea.replaceWith(newContent);

                // 버튼 복원
                target.textContent = "수정";
                target.classList.remove("save_mode");
            };

            target.addEventListener("click", saveHandler, { once: true });
        }
    });
});
