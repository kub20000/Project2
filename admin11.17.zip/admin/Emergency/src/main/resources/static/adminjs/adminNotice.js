// 더미데이터 (화면 확인용)
const noticeList = [
    { noticeId: 1, noticeTitle: "응급처치 교육 일정 변경 안내", noticeContent: "11월 응급처치 교육 일정이 내부 사정으로 변경되었습니다.", noticeRegDate: "2025-11-07" },
    { noticeId: 2, noticeTitle: "신규 강의 ‘심폐소생술 실습’ 오픈", noticeContent: "새로운 실습형 강의가 오픈되었습니다. 많은 참여 바랍니다.", noticeRegDate: "2025-10-30" },
    { noticeId: 3, noticeTitle: "사이트 점검 안내", noticeContent: "11월 1일 00:00~02:00 사이 서버 점검이 진행됩니다.", noticeRegDate: "2025-10-25" },
    { noticeId: 4, noticeTitle: "회원 정보 수정 기능 추가", noticeContent: "마이페이지에서 프로필 수정 기능이 새로 추가되었습니다.", noticeRegDate: "2025-10-20" },
    { noticeId: 5, noticeTitle: "응급 교육 수료증 발급 오류 안내", noticeContent: "일부 회원의 수료증 발급 오류가 수정되었습니다.", noticeRegDate: "2025-10-15" },
    { noticeId: 6, noticeTitle: "안전교육 콘텐츠 업데이트", noticeContent: "기초 안전교육 영상 콘텐츠가 새로 업데이트되었습니다.", noticeRegDate: "2025-10-10" },
    { noticeId: 7, noticeTitle: "포인트 상점 시스템 점검 안내", noticeContent: "10월 5일 오전 중 잠시 포인트 상점이 중단됩니다.", noticeRegDate: "2025-10-04" },
    { noticeId: 8, noticeTitle: "사이트 오픈 공지", noticeContent: "‘LIFE SAVER’ 응급·안전 교육 플랫폼이 정식 오픈했습니다!", noticeRegDate: "2025-09-30" },
    { noticeId: 9, noticeTitle: "사이트 오픈 공지", noticeContent: "‘LIFE SAVER’ 응급·안전 교육 플랫폼이 정식 오픈했습니다!", noticeRegDate: "2025-09-30" },
    { noticeId: 10, noticeTitle: "사이트 오픈 공지", noticeContent: "‘LIFE SAVER’ 응급·안전 교육 플랫폼이 정식 오픈했습니다!", noticeRegDate: "2025-09-30" },
    { noticeId: 11, noticeTitle: "사이트 오픈 공지", noticeContent: "‘LIFE SAVER’ 응급·안전 교육 플랫폼이 정식 오픈했습니다!", noticeRegDate: "2025-09-30" }
];

const tbody = document.querySelector("#admin_notice_table tbody");
const noticeTotalCount = document.getElementById("admin_tot_cnt");

// 공지사항 테이블 렌더링 함수
function renderNoticeTable(page) {
    tbody.innerHTML = "";

    const start = (page - 1) * rowsPerPage;
    const end = start + rowsPerPage;
    const pageData = noticeList.slice(start, end);

    pageData.forEach((n, idx) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
    <tr>
      <td>${start + idx + 1}</td>
      <td>
        <a href="adminNoticeEdit.html?id=${n.noticeId}" class="notice_title_link">${n.noticeTitle}</a>
      </td>
      <td>${n.noticeContent}</td>
      <td>관리자</td>
      <td>${n.noticeRegDate}</td>
      <td>
        <button class="admin_delete_btn" data-notice-id="${n.noticeId}">삭제</button>
      </td>
    </tr>
    `;
        tbody.appendChild(tr);
    });
    noticeTotalCount.textContent = noticeList.length.toString().padStart(2, "0");
    attachDeleteEvents();
}

// 삭제 버튼 이벤트
function attachDeleteEvents() {
    document.querySelectorAll(".admin_delete_btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
            const noticeId = parseInt(e.target.dataset.noticeId);
            const confirmDelete = confirm("정말로 공지사항을 삭제하시겠습니까?");
            if (confirmDelete) {
                const index = noticeList.findIndex(n => n.noticeId === noticeId);
                if (index !== -1) {
                    noticeList.splice(index, 1);
                    alert("공지사항이 삭제되었습니다.");
                    renderNoticeTable(currentPage);
                    renderPagination(noticeList.length);
                }
            }
        });
    });
}

// 행 개수 변경
rowSelect.addEventListener("change", function () {
    rowsPerPage = parseInt(this.value);
    currentPage = 1;
    renderNoticeTable(currentPage);
    renderPagination(noticeList.length);
});

// 공지사항 목록 페이징 처리
function changePage(page) {
    currentPage = page;
    renderNoticeTable(currentPage);
    renderPagination(noticeList.length);
}

// 초기 실행
renderNoticeTable(currentPage);
renderPagination(noticeList.length);
