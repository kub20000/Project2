package com.emergency.docs.repository;

import com.emergency.docs.domain.Material;
import com.emergency.docs.domain.MidCategory;
import com.emergency.docs.domain.TopCategory;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class MaterialRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<Material> materialRowMapper = (rs, rowNum) -> {
        Material m = new Material();
        m.setMaterialId(rs.getLong("material_id"));
        m.setTitle(rs.getString("title"));

        // ★ DB 값(한글 ENUM) → Enum 으로 변환
        String topDb = rs.getString("top_category");
        String midDb = rs.getString("mid_category");
        m.setTopCategory(TopCategory.fromDbValue(topDb));
        m.setMidCategory(MidCategory.fromDbValue(midDb));

        m.setContentHtml(rs.getString("content_html"));
        m.setUserId(rs.getLong("user_id"));
        m.setPdfPath(rs.getString("pdf_path"));

        var ts = rs.getTimestamp("created_at");
        if (ts != null) {
            m.setCreatedAt(ts.toLocalDateTime());
        }

        // ✅ JOIN 해서 가져온 작성자 이름
        //   (SELECT ... u.name AS writer_name 에서 매핑)
        m.setWriterName(rs.getString("writer_name"));

        return m;
    };

    /** 전체 목록 */
    public List<Material> findAll() {
        String sql = """
                SELECT m.material_id,
                       m.title,
                       m.top_category,
                       m.mid_category,
                       m.content_html,
                       m.user_id,
                       m.created_at,
                       m.pdf_path,
                       u.name AS writer_name
                  FROM materials m
                  LEFT JOIN users u ON u.user_id = m.user_id
                 ORDER BY m.material_id DESC
                """;
        return jdbcTemplate.query(sql, materialRowMapper);
    }

    /** 단건 조회 */
    public Optional<Material> findById(Long id) {
        String sql = """
                SELECT m.material_id,
                       m.title,
                       m.top_category,
                       m.mid_category,
                       m.content_html,
                       m.user_id,
                       m.created_at,
                       m.pdf_path,
                       u.name AS writer_name
                  FROM materials m
                  LEFT JOIN users u ON u.user_id = m.user_id
                 WHERE m.material_id = ?
                """;
        List<Material> list = jdbcTemplate.query(sql, materialRowMapper, id);
        return list.stream().findFirst();
    }

    /** 전체 개수 (카테고리 + 제목검색) */
    public int count(String topCategory, String keyword) {
        StringBuilder sb = new StringBuilder("SELECT COUNT(*) FROM materials m");
        List<Object> params = new ArrayList<>();
        boolean whereAdded = false;

        if (topCategory != null && !topCategory.isBlank()) {
            sb.append(" WHERE m.top_category = ?");
            params.add(topCategory);
            whereAdded = true;
        }

        if (keyword != null && !keyword.isBlank()) {
            sb.append(whereAdded ? " AND " : " WHERE");
            sb.append(" m.title LIKE ?");
            params.add("%" + keyword + "%");
        }

        Integer cnt = jdbcTemplate.queryForObject(
                sb.toString(),
                Integer.class,
                params.toArray()
        );
        return (cnt != null) ? cnt : 0;
    }

    /** 목록 조회 (검색 + 카테고리 + 페이징) */
    public List<Material> search(String topCategory,
                                 String keyword,
                                 int size,
                                 int offset) {

        StringBuilder sb = new StringBuilder("""
                SELECT m.material_id,
                       m.title,
                       m.top_category,
                       m.mid_category,
                       m.content_html,
                       m.user_id,
                       m.created_at,
                       m.pdf_path,
                       u.name AS writer_name
                  FROM materials m
                  LEFT JOIN users u ON u.user_id = m.user_id
                """);

        List<Object> params = new ArrayList<>();
        boolean whereAdded = false;

        if (topCategory != null && !topCategory.isBlank()) {
            sb.append(" WHERE m.top_category = ?");
            params.add(topCategory);
            whereAdded = true;
        }

        if (keyword != null && !keyword.isBlank()) {
            sb.append(whereAdded ? " AND " : " WHERE");
            sb.append(" m.title LIKE ?");
            params.add("%" + keyword + "%");
        }

        sb.append(" ORDER BY m.material_id DESC ");
        sb.append(" LIMIT ? OFFSET ? ");

        params.add(size);
        params.add(offset);

        return jdbcTemplate.query(sb.toString(), materialRowMapper, params.toArray());
    }

    /** 신규 저장 (INSERT) */
    public Long save(Material material) {
        String sql = """
        INSERT INTO materials
            (title, top_category, mid_category, content_html, user_id, pdf_path)
        VALUES (?, ?, ?, ?, ?, ?)
        """;

        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(con -> {
            PreparedStatement ps =
                    con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, material.getTitle());
            ps.setString(2, material.getTopCategory().getDbValue());
            ps.setString(3, material.getMidCategory().getDbValue());
            ps.setString(4, material.getContentHtml());
            ps.setLong(5, material.getUserId());
            ps.setString(6, material.getPdfPath());
            return ps;
        }, keyHolder);

        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    /** 수정 (파일 포함) */
    public void update(Material material) {
        String sql = """
                UPDATE materials
                   SET title = ?,
                       top_category = ?,
                       mid_category = ?,
                       content_html = ?,
                       pdf_path = ?
                 WHERE material_id = ?
                """;
        jdbcTemplate.update(sql,
                material.getTitle(),
                material.getTopCategory().getDbValue(),
                material.getMidCategory().getDbValue(),
                material.getContentHtml(),
                material.getPdfPath(),
                material.getMaterialId());
    }

    /** 수정 (파일 변경 없음) */
    public void updateWithoutFile(Material material) {
        String sql = """
        UPDATE materials
           SET title = ?,
               top_category = ?,
               mid_category = ?,
               content_html = ?
         WHERE material_id = ?
        """;
        jdbcTemplate.update(sql,
                material.getTitle(),
                material.getTopCategory().getDbValue(),
                material.getMidCategory().getDbValue(),
                material.getContentHtml(),
                material.getMaterialId());
    }

    /** 삭제 */
    public void delete(Long id) {
        jdbcTemplate.update("DELETE FROM materials WHERE material_id = ?", id);
    }
}
