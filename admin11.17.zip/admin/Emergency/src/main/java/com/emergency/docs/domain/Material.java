package com.emergency.docs.domain;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Material {

    private Long materialId;     // material_id
    private String title;        // title
    private TopCategory topCategory;  // top_category (예: TOP_A)
    private MidCategory midCategory;  // mid_category (예: MID_1)
    private String contentHtml;  // content_html
    private Long userId;         // user_id
    private LocalDateTime createdAt; // created_at
    private String pdfPath;      // pdf_path (실제 저장된 경로)
    private String writerName;
}
