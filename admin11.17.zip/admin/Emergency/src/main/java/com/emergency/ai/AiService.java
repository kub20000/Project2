//package com.emergency.ai;
//
//import com.openai.client.OpenAIClient;
//import com.openai.client.okhttp.OpenAIOkHttpClient;
//import com.openai.models.responses.Response;
//import com.openai.models.responses.ResponseCreateParams;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//import java.util.List;
//
//@Service
//public class AiService {
//    private final OpenAIClient client;
//    private final String model;
//
//    // fromEnv()는 OPENAI_API_KEY 환경변수를 자동으로 읽음
//    public AiService(@Value("${openai.model}") String model) {
//        this.client = OpenAIOkHttpClient.fromEnv();
//        this.model = model; // 예: gpt-4.1-mini
//    }
//
//}
