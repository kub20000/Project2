package com.emergency.docs.service;

import com.emergency.docs.domain.Material;
import com.emergency.docs.domain.TopCategory;
import com.emergency.docs.domain.MidCategory;
import com.emergency.docs.repository.MaterialRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MaterialService {

    private final MaterialRepository materialRepository;

    // application.yml / properties 에 설정
    @Value("${docs.storage.base-path}")
    private String storageBasePath;

    public List<Material> findAll() {
        return materialRepository.findAll();
    }
    public int count(String topCategory, String keyword) {
        return materialRepository.count(topCategory, keyword);
    }
    public List<Material> search(String topCategory,
                                 String keyword,
                                 int page,
                                 int size) {
        if (page < 1) page = 1;
        if (size <= 0) size = 10;

        int offset = (page - 1) * size;
        return materialRepository.search(topCategory, keyword, size, offset);
    }

    public Optional<Material> findById(Long id) {
        return materialRepository.findById(id);
    }

    /**
     * 등록
     */
    public Long create(String title,
                       String contentHtml,
                       TopCategory topCategory,
                       MidCategory midCategory,
                       Long userId,
                       MultipartFile pdfFile) throws IOException {

        if (pdfFile == null || pdfFile.isEmpty()) {
            throw new IllegalArgumentException("첨부파일(PDF)은 필수입니다.");
        }

        String storedPath = storeFile(pdfFile);   // 실제 파일 저장

        Material material = new Material();
        material.setTitle(title);

        // ★ enum 그대로 세팅 (String 아님)
        material.setTopCategory(topCategory);
        material.setMidCategory(midCategory);

        material.setContentHtml(contentHtml);
        material.setUserId(userId);
        material.setPdfPath(storedPath);          // 전체 경로 저장

        return materialRepository.save(material);
    }

    /**
     * 수정
     */
    public void update(Long id,
                       String title,
                       String contentHtml,
                       TopCategory topCategory,
                       MidCategory midCategory,
                       Long userId,
                       MultipartFile pdfFile) throws IOException {

        Material material = materialRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("교육자료를 찾을 수 없습니다. id=" + id));

        material.setTitle(title);
        material.setContentHtml(contentHtml);
        material.setUserId(userId);

        // ★ enum 그대로 세팅
        if (topCategory != null) {
            material.setTopCategory(topCategory);
        }
        if (midCategory != null) {
            material.setMidCategory(midCategory);
        }

        if (pdfFile != null && !pdfFile.isEmpty()) {
            // 기존 파일 삭제 + 새 파일 저장
            deletePhysicalFile(material.getPdfPath());
            String storedPath = storeFile(pdfFile);
            material.setPdfPath(storedPath);
            materialRepository.update(material);
        } else {
            // 파일 변경 X (제목/내용/카테고리/작성자만 수정)
            materialRepository.updateWithoutFile(material);
        }
    }

    /**
     * 삭제 (DB + 실제 파일)
     */
    public void delete(Long id) {
        materialRepository.findById(id)
                .ifPresent(m -> deletePhysicalFile(m.getPdfPath()));
        materialRepository.delete(id);
    }

    /** 저장 경로 리턴 (다운로드용에서 쓰고 싶으면 getter 추가해도 됨) */
    public String getStorageBasePath() {
        return storageBasePath;
    }

    // ------------------ 내부 유틸 ------------------ //

    private String storeFile(MultipartFile file) throws IOException {

        // base-path/materials 디렉터리에 저장
        Path dir = Paths.get(storageBasePath, "materials");
        Files.createDirectories(dir);

        String ext = "";
        String originalName = file.getOriginalFilename();
        if (originalName != null && originalName.contains(".")) {
            ext = originalName.substring(originalName.lastIndexOf("."));
        }

        String storedName = UUID.randomUUID() + ext;
        Path target = dir.resolve(storedName);

        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

        // DB 에는 실제 경로 전체 저장
        return target.toString();
    }

    private void deletePhysicalFile(String pdfPath) {
        if (pdfPath == null || pdfPath.isBlank()) return;
        try {
            Files.deleteIfExists(Paths.get(pdfPath));
        } catch (IOException e) {
            // 로그 정도만 찍어두고 무시해도 괜찮음
            e.printStackTrace();
        }
    }
}
