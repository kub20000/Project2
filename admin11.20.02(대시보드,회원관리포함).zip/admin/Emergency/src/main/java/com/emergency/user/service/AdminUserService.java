package com.emergency.user.service;

import com.emergency.user.repository.AdminUserRepository;
import com.emergency.user.web.dto.AdminUserCourseDto;
import com.emergency.user.web.dto.AdminUserListDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AdminUserService {

    private final AdminUserRepository adminUserRepository;

    public List<AdminUserListDto> getUserListForAdmin() {
        return adminUserRepository.findAllNormalUsers();
    }

    public List<AdminUserCourseDto> getUserCourses(Long userId) {
        return adminUserRepository.findCoursesByUserId(userId);
    }
}
